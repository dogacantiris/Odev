﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace ETicaretScript.Entity
{
    public class IdentityContext:DbContext
    {
        public IdentityContext():base("IdentityDatabase")
        {
            Database.SetInitializer(new IdentityInitilaizer());
        }

        public DbSet<IdentityEntity> Identities { get; set; }
    }
}