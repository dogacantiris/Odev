﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace ETicaretScript.Entity
{
    public class IdentityInitilaizer:DropCreateDatabaseIfModelChanges<IdentityContext>
    {
        protected override void Seed(IdentityContext context)
        {
            List<IdentityEntity> identity = new List<IdentityEntity>()
            {
                new IdentityEntity(){NickName="Eray",Password="123456",Role="User"},
                 new IdentityEntity(){NickName="Admin",Password="Admin",Role="Admin"}
            };

            foreach (var item in identity)
            {
                context.Identities.Add(item);
            }
            context.SaveChanges();


            base.Seed(context);
        }
    }
}