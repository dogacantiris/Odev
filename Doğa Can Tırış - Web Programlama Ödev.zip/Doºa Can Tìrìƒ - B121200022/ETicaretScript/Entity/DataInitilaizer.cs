﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace ETicaretScript.Entity
{
    public class DataInitilaizer : DropCreateDatabaseIfModelChanges<DataContext>
    {
        protected override void Seed(DataContext context)
        {

            List<Category> categories = new List<Category>()
            {
                new Category(){CategoryName="Teknoloji",Description="Son Model Teknoloji Ürünleri"},
                new Category(){CategoryName="Beyaz Eşya",Description="Son Model Beyaz Eşya Ürünleri"},
                new Category(){CategoryName="Mobilya",Description="Son Moda  Mobilyalar"},
                new Category(){CategoryName="Spor Aletleri",Description="En Kaliteli Spor Aletleri"}
            };

            foreach (var item in categories)
            {
                context.Categories.Add(item);
            }
            context.SaveChanges();

            List<Product> products = new List<Product>()
            {
                new Product(){ProductName="Lenovo Z500",Description="i7 İşlemcili",IsApproved=true,Price=2500.78,Stock=24,CategoryId=1,IsHomePage=true,Photo="https://i.ytimg.com/vi/JR3GfeoycpI/maxresdefault.jpg"},
                new Product(){ProductName="Bosch Çamaşır Makinesi",Description="Yeni Seçenekler",IsApproved=true,Price=3500.78,Stock=4,CategoryId=2,IsHomePage=true,Photo="https://media3.bosch-home.com/Product_Shots/435x515/MCSA00419072_WAS247B3TR_def.png "},
                new Product(){ProductName="İstikbal Koltuk Takımı",Description="Renk Çeşitleri",IsApproved=false,Price=5500.78,Stock=24,CategoryId=3,IsHomePage=true,Photo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSK4uYmpEfWQ7F4wpopLmxpXhUqB_m6rc9s82B2OXzCx-ct0s0S"},
                new Product(){ProductName="Dumbell Seti",Description="Ağırlık Çeşitleri",IsApproved=true,Price=200.78,Stock=100,CategoryId=4,IsHomePage=false,Photo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR5rJzWv4iS6wxJSfJiF-y-vSolccomL1J9GTiuu3AuRNdZLUoMIA"},
                  new Product(){ProductName="Lenovo Z500",Description="i7 İşlemcili",IsApproved=true,Price=2500.78,Stock=24,CategoryId=1,IsHomePage=true,Photo="https://i.ytimg.com/vi/JR3GfeoycpI/maxresdefault.jpg"},
                new Product(){ProductName="Bosch Çamaşır Makinesi",Description="Yeni Seçenekler",IsApproved=false,Price=3500.78,Stock=4,CategoryId=2,IsHomePage=false,Photo="https://media3.bosch-home.com/Product_Shots/435x515/MCSA00419072_WAS247B3TR_def.png "},
                new Product(){ProductName="İstikbal Koltuk Takımı",Description="Renk Çeşitleri",IsApproved=true,Price=5500.78,Stock=24,CategoryId=3,IsHomePage=true,Photo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSK4uYmpEfWQ7F4wpopLmxpXhUqB_m6rc9s82B2OXzCx-ct0s0S"},
                new Product(){ProductName="Dumbell Seti",Description="Ağırlık Çeşitleri",IsApproved=false,Price=200.78,Stock=100,CategoryId=4,IsHomePage=true,Photo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR5rJzWv4iS6wxJSfJiF-y-vSolccomL1J9GTiuu3AuRNdZLUoMIA"},
                  new Product(){ProductName="Lenovo Z500",Description="i7 İşlemcili",IsApproved=true,Price=2500.78,Stock=24,CategoryId=1,IsHomePage=false,Photo="https://i.ytimg.com/vi/JR3GfeoycpI/maxresdefault.jpg"},
                new Product(){ProductName="Bosch Çamaşır Makinesi",Description="Yeni Seçenekler",IsApproved=true,Price=3500.78,Stock=4,CategoryId=2,IsHomePage=true,Photo="https://media3.bosch-home.com/Product_Shots/435x515/MCSA00419072_WAS247B3TR_def.png "},
                new Product(){ProductName="İstikbal Koltuk Takımı",Description="Renk Çeşitleri",IsApproved=false,Price=5500.78,Stock=24,CategoryId=3,IsHomePage=false,Photo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSK4uYmpEfWQ7F4wpopLmxpXhUqB_m6rc9s82B2OXzCx-ct0s0S"},
                new Product(){ProductName="Dumbell Seti",Description="Ağırlık Çeşitleri",IsApproved=true,Price=200.78,Stock=100,CategoryId=4,IsHomePage=true,Photo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR5rJzWv4iS6wxJSfJiF-y-vSolccomL1J9GTiuu3AuRNdZLUoMIA"},
                  new Product(){ProductName="Lenovo Z500",Description="i7 İşlemcili",IsApproved=true,Price=2500.78,Stock=24,CategoryId=1,IsHomePage=true,Photo="https://i.ytimg.com/vi/JR3GfeoycpI/maxresdefault.jpg"},
                new Product(){ProductName="Bosch Çamaşır Makinesi",Description="Yeni Seçenekler",IsApproved=true,Price=3500.78,Stock=0,CategoryId=2,IsHomePage=true,Photo="https://media3.bosch-home.com/Product_Shots/435x515/MCSA00419072_WAS247B3TR_def.png "},
                new Product(){ProductName="İstikbal Koltuk Takımı",Description="Renk Çeşitleri",IsApproved=true,Price=5500.78,Stock=24,CategoryId=3,IsHomePage=true,Photo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSK4uYmpEfWQ7F4wpopLmxpXhUqB_m6rc9s82B2OXzCx-ct0s0S"},
                new Product(){ProductName="Dumbell Seti",Description="Ağırlık Çeşitleri",IsApproved=true,Price=200.78,Stock=100,CategoryId=4,IsHomePage=true,Photo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR5rJzWv4iS6wxJSfJiF-y-vSolccomL1J9GTiuu3AuRNdZLUoMIA"},
                  new Product(){ProductName="Lenovo Z500",Description="i7 İşlemcili",IsApproved=true,Price=2500.78,Stock=24,CategoryId=1,IsHomePage=true,Photo="https://i.ytimg.com/vi/JR3GfeoycpI/maxresdefault.jpg"},
                new Product(){ProductName="Bosch Çamaşır Makinesi",Description="Yeni Seçenekler",IsApproved=true,Price=3500.78,Stock=4,CategoryId=2,IsHomePage=true,Photo="https://media3.bosch-home.com/Product_Shots/435x515/MCSA00419072_WAS247B3TR_def.png "},
                new Product(){ProductName="İstikbal Koltuk Takımı",Description="Renk Çeşitleri",IsApproved=true,Price=5500.78,Stock=0,CategoryId=3,IsHomePage=true,Photo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSK4uYmpEfWQ7F4wpopLmxpXhUqB_m6rc9s82B2OXzCx-ct0s0S"},
                new Product(){ProductName="Dumbell Seti",Description="Ağırlık Çeşitleri",IsApproved=true,Price=200.78,Stock=100,CategoryId=4,IsHomePage=true,Photo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR5rJzWv4iS6wxJSfJiF-y-vSolccomL1J9GTiuu3AuRNdZLUoMIA"},
                  new Product(){ProductName="Lenovo Z500",Description="i7 İşlemcili",IsApproved=true,Price=2500.78,Stock=24,CategoryId=1,IsHomePage=true,Photo="https://i.ytimg.com/vi/JR3GfeoycpI/maxresdefault.jpg"},
                new Product(){ProductName="Bosch Çamaşır Makinesi",Description="Yeni Seçenekler",IsApproved=true,Price=3500.78,Stock=0,CategoryId=2,IsHomePage=true,Photo="https://media3.bosch-home.com/Product_Shots/435x515/MCSA00419072_WAS247B3TR_def.png "},
                new Product(){ProductName="İstikbal Koltuk Takımı",Description="Renk Çeşitleri",IsApproved=true,Price=5500.78,Stock=24,CategoryId=3,IsHomePage=true,Photo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSK4uYmpEfWQ7F4wpopLmxpXhUqB_m6rc9s82B2OXzCx-ct0s0S"},
                new Product(){ProductName="Dumbell Seti",Description="Ağırlık Çeşitleri",IsApproved=true,Price=200.78,Stock=0,CategoryId=4,IsHomePage=true,Photo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR5rJzWv4iS6wxJSfJiF-y-vSolccomL1J9GTiuu3AuRNdZLUoMIA"},

            };

            foreach (var item in products)
            {
                context.Products.Add(item);
            }
            context.SaveChanges();



            base.Seed(context);
        }
    }
}