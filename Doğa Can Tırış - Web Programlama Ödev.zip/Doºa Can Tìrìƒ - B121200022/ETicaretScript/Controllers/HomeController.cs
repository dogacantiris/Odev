﻿using ETicaretScript.Entity;
using ETicaretScript.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ETicaretScript.Controllers
{
    public class HomeController : Controller
    {

        DataContext db = new DataContext();
        // GET: Home
        public ActionResult Index()
        {
            var urunler = db.Products.Where(i => i.IsApproved == true && i.IsHomePage == true).Select(i => new ProductModel
            {
                Id = i.Id,
                Description = i.Description.Length > 11 ? i.Description.Substring(0, 10)+".." : i.Description,
                Photo = i.Photo,
                Price = i.Price,
                ProductName = i.ProductName.Length > 11 ? i.ProductName.Substring(0, 10) + ".." : i.ProductName,
                Stock = i.Stock
            }).ToList();

            return View(urunler);
        }

        public ActionResult Details(int id)
        {
            var urun = db.Products.Where(i => i.Id == id).FirstOrDefault();
            return View(urun);
        }

       
       
        public ActionResult List(int? id)
        {
            var urunler = db.Products.Select(i => new ProductModel
            {
                Id = i.Id,
                Description = i.Description.Length > 11 ? i.Description.Substring(0, 10) + ".." : i.Description,
                Photo = i.Photo,
                Price = i.Price,
                ProductName = i.ProductName.Length > 11 ? i.ProductName.Substring(0, 10) + ".." : i.ProductName,
                Stock = i.Stock,
                CategoryId=i.CategoryId
            }).AsQueryable();

            if (id==null)
            {
                return View(urunler.ToList());
            }
            else
            {
                urunler=urunler.Where(i => i.CategoryId == id);
                ViewBag.UrunSayisi = urunler.Count();
                return View(urunler.ToList());
            }

            
        }

        public PartialViewResult CategoryList()
        {

            var kategoriler = db.Categories.ToList();

            return PartialView(kategoriler);
        }
             
    }
}