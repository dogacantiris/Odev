﻿using ETicaretScript.Entity;
using ETicaretScript.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ETicaretScript.Controllers
{
    public class ProductController : Controller
    {
        DataContext db = new DataContext();
        // GET: Product
        public ActionResult Index()
        {
            var urunler = db.Products.Select(i => new ProductModel
            {
                Id = i.Id,
                ProductName = i.ProductName,
                Photo = i.Photo,
                Price = i.Price,
                Stock = i.Stock,
                IsApproved = i.IsApproved,
                IsHomePage = i.IsHomePage,
                Description = i.Description,
                Category = i.Category,
                CategoryId = i.CategoryId
            }
            ).ToList();
            if (Session["LogOnUser"] == null)
            {
                return RedirectToAction("Login","Identity");
            }
            else
            {
                if (((IdentityEntity)Session["LogOnUser"]).Role == "Admin")
                {
                    return View(urunler);
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
            }
        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            var urun = db.Products.Where(i => i.Id == id).FirstOrDefault();
            ViewBag.Kategoriler = db.Categories;
            if (Session["LogOnUser"] == null)
            {
                return RedirectToAction("Login", "Identity");
            }
            else
            {
                if (((IdentityEntity)Session["LogOnUser"]).Role == "Admin")
                {
                    return View(urun);
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
            }

            
            
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Product urun)
        {
            db.Products.Find(urun.Id).CategoryId = urun.CategoryId;
            db.Products.Find(urun.Id).Description = urun.Description;
            db.Products.Find(urun.Id).IsApproved = urun.IsApproved;
            db.Products.Find(urun.Id).IsHomePage = urun.IsHomePage;
            db.Products.Find(urun.Id).Photo = urun.Photo;
            db.Products.Find(urun.Id).Price = urun.Price;
            db.Products.Find(urun.Id).ProductName = urun.ProductName;
            db.Products.Find(urun.Id).Stock = urun.Stock;
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Create()
        {
            ViewBag.kategori = db.Categories.ToList();
            if (Session["LogOnUser"] == null)
            {
                return RedirectToAction("Login", "Identity");
            }
            else
            {
                if (((IdentityEntity)Session["LogOnUser"]).Role == "Admin")
                {
                    return View();
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
            }
            
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Product urun)
        {
            
            db.Products.Add(urun);
            db.SaveChanges();

            return RedirectToAction("Index");
        }

        
        public ActionResult Delete(int id)
        {
            db.Products.Remove(db.Products.Find(id));
            db.SaveChanges();
            return RedirectToAction("Index");
        }

    }

    
}