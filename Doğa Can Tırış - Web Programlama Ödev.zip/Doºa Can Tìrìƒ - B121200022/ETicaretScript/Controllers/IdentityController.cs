﻿using ETicaretScript.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ETicaretScript.Controllers
{
    public class IdentityController : Controller
    {
        // GET: Identity
        IdentityContext db = new IdentityContext();
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Login()
        {
            if (Session["LogOnUser"]==null)
            {
                return View();
            }
            else
            {
                if (((IdentityEntity)Session["LogOnUser"]).Role == "Admin")
                {
                    return RedirectToAction("Index", "Product");
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
            }

            
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(IdentityEntity entity)
        {
            var user = db.Identities.Where(i => i.NickName == entity.NickName && i.Password == entity.Password).FirstOrDefault();   

            if (db.Identities.Any(i=>i.NickName==entity.NickName && i.Password==entity.Password))
            {
                Session["LogOnUser"] = db.Identities.Where(i => i.NickName == entity.NickName && i.Password == entity.Password).FirstOrDefault();

                if (user.Role=="Admin")
                {
                    return RedirectToAction("Index","Product");
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
            }
            else
            {
                return View();
            }

        }

        [HttpGet]
        public ActionResult Register()
        {

            if (Session["LogOnUser"] == null)
            {
                return View();
            }
            else
            {
                if (((IdentityEntity)Session["LogOnUser"]).Role == "Admin")
                {
                    return RedirectToAction("Index", "Product");
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
            }

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register(IdentityEntity entity)
        {
            entity.Role = "User";
            db.Identities.Add(entity);
            db.SaveChanges();
            Session["LogOnUser"] = entity;
            return RedirectToAction("Index","Home");
        }

        public ActionResult Exit()
        {
            Session["LogOnUser"] = null;

            return RedirectToAction("Index","Home");
        }


    }
}