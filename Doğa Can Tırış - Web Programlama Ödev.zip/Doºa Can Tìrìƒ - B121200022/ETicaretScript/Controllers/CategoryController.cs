﻿using ETicaretScript.Entity;
using ETicaretScript.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ETicaretScript.Controllers
{
    public class CategoryController : Controller
    {
        DataContext db = new DataContext();
        // GET: Category
        public ActionResult Index()
        {

            var kategoriler = db.Categories.Select(i => new CategoryModel
            {
                Id=i.Id,CategoryName=i.CategoryName,Description=i.Description,Products=i.Products,ProductsCount=i.Products.Count()
            }).ToList();
            if (Session["LogOnUser"] == null)
            {
                return RedirectToAction("Login", "Identity");
            }
            else
            {
                if (((IdentityEntity)Session["LogOnUser"]).Role == "Admin")
                {
                    return View(kategoriler);
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
            }
            
        }

        [HttpGet]
        public ActionResult Create()
        {
            if (Session["LogOnUser"] == null)
            {
                return RedirectToAction("Login", "Identity");
            }
            else
            {
                if (((IdentityEntity)Session["LogOnUser"]).Role == "Admin")
                {
                    return View();
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
            }
            
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Category kategori)
        {
            db.Categories.Add(kategori);
            db.SaveChanges();
          return RedirectToAction("Index");
        }

        public ActionResult Edit(int id)
        {
            var kategoriler = db.Categories.Where(i => i.Id == id).FirstOrDefault();
            if (Session["LogOnUser"] == null)
            {
                return RedirectToAction("Login", "Identity");
            }
            else
            {
                if (((IdentityEntity)Session["LogOnUser"]).Role == "Admin")
                {
                    return View(kategoriler);
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
            }
           
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Category kategori)
        {
            db.Categories.Find(kategori.Id).CategoryName = kategori.CategoryName;
            db.Categories.Find(kategori.Id).Description = kategori.Description;
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult Delete(int id)
        {
            db.Categories.Remove(db.Categories.Find(id));
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult Details(int id)
        {
            var kategoriler = db.Categories.Select(i => new CategoryModel
            {
                Id = i.Id,
                CategoryName = i.CategoryName,
                Description = i.Description,
                Products = i.Products,
                ProductsCount = i.Products.Count()
            }).ToList();
            return View(kategoriler);
        }

    }
}